create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  marketplace text not null check (marketplace in ('amazon','flipkart','meesho','myntra')),
  asin text,
  title text not null,
  brand text,
  image_url text not null,
  price numeric,
  currency text default 'INR',
  rating numeric,
  features jsonb default '[]'::jsonb,
  affiliate_url text not null,
  featured boolean default false,
  trending boolean default false,
  description text,
  created_at timestamptz default now()
);

create index if not exists products_marketplace_idx on public.products(marketplace);
create index if not exists products_featured_idx on public.products(featured);
create index if not exists products_trending_idx on public.products(trending);

create table if not exists public.site_settings (
  id integer primary key default 1,
  site_name text not null default 'DealCart India',
  site_description text default '',
  social_links jsonb default '[]'::jsonb,
  updated_at timestamptz default now()
);

insert into public.site_settings (id, site_name)
values (1, 'DealCart India')
on conflict (id) do nothing;

-- The app uses the Supabase service-role key only on the server.
-- Keep RLS enabled if you later expose Supabase directly to the browser.
alter table public.products enable row level security;
alter table public.site_settings enable row level security;
