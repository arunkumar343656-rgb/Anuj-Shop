# DealCart India — Affiliate Marketplace

Amazon-style shopping layout (without copying Amazon branding) for Amazon.in, Flipkart, Meesho and Myntra affiliate products.

## What is included

- 4 marketplace pages: `/amazon`, `/flipkart`, `/meesho`, `/myntra`
- Admin page: `/admin`
- Amazon affiliate URL → ASIN extraction
- Amazon Creators API product lookup
- Featured / Top Pick product
- Trending Picks flag
- Product search
- 4 social media links
- Supabase database
- Vercel-ready Next.js app
- Affiliate disclosure and `nofollow sponsored` outbound links

## Important Amazon API note

Amazon Product Advertising API 5.0 was deprecated and replaced by the Amazon Creators API. This project therefore uses Creators API rather than the old PA-API.

Amazon currently requires Associates enrollment and Creators API access/credentials. You must put your own credentials in Vercel environment variables.

## Setup

1. Create a Supabase project.
2. Open Supabase SQL Editor and run `supabase/schema.sql`.
3. Copy `.env.example` to `.env.local`.
4. Fill in:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `ADMIN_PASSWORD`
   - `AMAZON_CLIENT_ID`
   - `AMAZON_CLIENT_SECRET`
   - `AMAZON_PARTNER_TAG`
   - `AMAZON_MARKETPLACE=www.amazon.in`
5. Run:
   ```bash
   npm install
   npm run dev
   ```
6. Open `http://localhost:3000/admin`.
7. Enter your admin password.
8. Paste an Amazon product affiliate URL and press **Fetch Product**.
9. Review the returned data and press **Save Product**.
10. Choose **TOP PICK** if you want the product at the top.

## Deploy to Vercel

Push this project to GitHub, import the repository in Vercel, and add the same environment variables in Vercel Project Settings → Environment Variables. Then deploy.

## Security

Never put the Supabase service-role key or Amazon client secret in browser code. They are used only in Next.js server routes.

The admin password is a simple protection layer. For a production store with multiple admins, replace it with proper authentication.

## Affiliate compliance

Use your own approved affiliate accounts and follow each network's current operating agreement and link/product-display rules. Do not scrape Amazon pages to obtain product data. Use the official Creators API or another permitted data source.

## UI update
The homepage now uses a reference-inspired Indian deal-store layout: orange scrolling offer bar, logo/search header, category navigation, pink/cream hero area, hot-selling products, popular platforms, category tiles, top-pick/trending sections, 4-column product grid and mobile bottom navigation. It uses original DealCart branding rather than copying a third-party logo.
