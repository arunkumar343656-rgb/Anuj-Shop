import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { supabaseAdmin } from "@/lib/supabase";

const names={amazon:"Amazon.in",flipkart:"Flipkart",meesho:"Meesho",myntra:"Myntra"};
export const dynamic="force-dynamic";

export default async function MarketplacePage({params,searchParams}){
  const {marketplace}=await params; const qs=await searchParams;
  if(!names[marketplace]) return <div>Page not found</div>;
  let products=[],settings={site_name:"DealCart India",social_links:[]};
  try{
    const db=supabaseAdmin();
    const r=await db.from("products").select("*").eq("marketplace",marketplace).order("featured",{ascending:false}).order("trending",{ascending:false}).order("created_at",{ascending:false});
    products=r.data||[];
    const s=await db.from("site_settings").select("*").eq("id",1).single(); settings=s.data||settings;
  }catch{}
  const q=String(qs?.q||"").trim().toLowerCase();
  if(q) products=products.filter(p=>`${p.title} ${p.brand||""} ${p.description||""}`.toLowerCase().includes(q));
  const featured=products.filter(p=>p.featured),trending=products.filter(p=>p.trending&&!p.featured),regular=products.filter(p=>!p.featured&&!p.trending);
  return <>
    <Header siteName={settings.site_name}/>
    <section className="heroArea"><div className="container">
      <div className="notice">Affiliate disclosure: qualifying purchases made through our links may earn us a commission at no extra cost to you.</div>
    </div></section>
    {featured.length>0&&<section className="section" id="featured"><div className="container"><h2>⭐ {names[marketplace]} Top Picks</h2><div className="grid">{featured.map(p=><ProductCard key={p.id} product={p}/>)}</div></div></section>}
    {trending.length>0&&<section className="section" id="trending"><div className="container"><h2>🔥 Trending on {names[marketplace]}</h2><div className="grid">{trending.map(p=><ProductCard key={p.id} product={p}/>)}</div></div></section>}
    <section className="section"><div className="container"><h2>{q?`Search results for "${q}"`:`Latest ${names[marketplace]} Products`}</h2>{regular.length||q?<div className="grid">{(q?products:regular).map(p=><ProductCard key={p.id} product={p}/>)}</div>:<div className="empty">Admin panel se products add karein.</div>}</div></section>
    <Footer settings={settings}/>
    <div className="bottomNav"><a href="/amazon"><b>⌂</b>Shop</a><a href="#featured"><b>♡</b>Wishlist</a><a href="/admin"><b>▤</b>Blog</a><a href="/amazon"><b>⌂</b>Home</a></div>
  </>;
}
