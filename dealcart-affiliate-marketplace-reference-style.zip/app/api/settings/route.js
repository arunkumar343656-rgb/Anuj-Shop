import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

function ok(password) {
  return process.env.ADMIN_PASSWORD && password === process.env.ADMIN_PASSWORD;
}

export async function GET() {
  try {
    const db = supabaseAdmin();
    const { data, error } = await db.from("site_settings").select("*").eq("id", 1).single();
    if (error) throw error;
    return NextResponse.json({ settings: data });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    if (!ok(body.password)) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });

    const social_links = (body.social_links || []).slice(0, 4).map(x => ({
      label: String(x.label || "").slice(0, 30),
      url: String(x.url || "").slice(0, 500)
    }));

    const db = supabaseAdmin();
    const { data, error } = await db.from("site_settings").upsert({
      id: 1,
      site_name: String(body.site_name || "DealCart India"),
      site_description: String(body.site_description || ""),
      social_links
    }).select().single();

    if (error) throw error;
    return NextResponse.json({ settings: data });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
