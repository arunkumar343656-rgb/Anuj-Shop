import { NextResponse } from "next/server";
import { getAmazonProductFromUrl } from "@/lib/amazon";

export async function POST(request) {
  try {
    const { url, password } = await request.json();

    if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json({ error: "Invalid admin password." }, { status: 401 });
    }

    const product = await getAmazonProductFromUrl(url);
    return NextResponse.json({ product });
  } catch (error) {
    return NextResponse.json({ error: error.message || "Amazon product fetch failed." }, { status: 400 });
  }
}
