import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

const allowed = new Set(["amazon", "flipkart", "meesho", "myntra"]);

function checkPassword(password) {
  return process.env.ADMIN_PASSWORD && password === process.env.ADMIN_PASSWORD;
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const marketplace = searchParams.get("marketplace");

    const db = supabaseAdmin();
    let query = db.from("products").select("*").order("featured", { ascending: false }).order("created_at", { ascending: false });
    if (marketplace && allowed.has(marketplace)) query = query.eq("marketplace", marketplace);

    const { data, error } = await query;
    if (error) throw error;
    return NextResponse.json({ products: data || [] });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    if (!checkPassword(body.password)) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });

    const marketplace = body.marketplace || "amazon";
    if (!allowed.has(marketplace)) throw new Error("Invalid marketplace.");

    const product = {
      marketplace,
      asin: body.asin || null,
      title: String(body.title || "").trim(),
      brand: String(body.brand || "").trim(),
      image_url: String(body.image_url || "").trim(),
      price: body.price === "" || body.price == null ? null : Number(body.price),
      currency: body.currency || "INR",
      rating: body.rating === "" || body.rating == null ? null : Number(body.rating),
      features: Array.isArray(body.features) ? body.features.slice(0, 12) : [],
      affiliate_url: String(body.affiliate_url || "").trim(),
      featured: Boolean(body.featured),
      trending: Boolean(body.trending),
      description: String(body.description || "").trim()
    };

    if (!product.title || !product.affiliate_url || !product.image_url) {
      throw new Error("Title, image URL aur affiliate URL required hain.");
    }

    const db = supabaseAdmin();

    if (product.featured) {
      await db.from("products").update({ featured: false }).eq("marketplace", marketplace);
    }

    const { data, error } = await db.from("products").insert(product).select().single();
    if (error) throw error;

    return NextResponse.json({ product: data });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}

export async function DELETE(request) {
  try {
    const body = await request.json();
    if (!checkPassword(body.password)) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
    if (!body.id) throw new Error("Product id required.");

    const db = supabaseAdmin();
    const { error } = await db.from("products").delete().eq("id", body.id);
    if (error) throw error;

    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
