 "use client";

import { useEffect, useState } from "react";

const marketplaces = ["amazon","flipkart","meesho","myntra"];

export default function AdminPage() {
  const [password, setPassword] = useState("");
  const [marketplace, setMarketplace] = useState("amazon");
  const [url, setUrl] = useState("");
  const [form, setForm] = useState({
    title:"", brand:"", image_url:"", price:"", currency:"INR", rating:"",
    features:"", affiliate_url:"", description:"", featured:false, trending:false, asin:""
  });
  const [products, setProducts] = useState([]);
  const [settings, setSettings] = useState({site_name:"DealCart India",site_description:"",social_links:[{label:"",url:""},{label:"",url:""},{label:"",url:""},{label:"",url:""}]});
  const [status, setStatus] = useState("");

  async function loadProducts() {
    const r = await fetch(`/api/products?marketplace=${marketplace}`);
    const d = await r.json();
    setProducts(d.products || []);
  }
  async function loadSettings() {
    const r = await fetch("/api/settings");
    const d = await r.json();
    if (d.settings) {
      const links = Array.isArray(d.settings.social_links) ? d.settings.social_links : [];
      while (links.length < 4) links.push({label:"",url:""});
      setSettings({...d.settings, social_links:links.slice(0,4)});
    }
  }
  useEffect(() => { loadProducts(); }, [marketplace]);
  useEffect(() => { loadSettings(); }, []);

  function setField(key, value) { setForm(f => ({...f, [key]:value})); }

  async function fetchAmazon() {
    setStatus("Amazon se product details fetch ho rahe hain...");
    const r = await fetch("/api/amazon/product", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify({url, password})
    });
    const d = await r.json();
    if (!r.ok) return setStatus(d.error || "Failed");
    const p = d.product;
    setForm({
      title:p.title || "", brand:p.brand || "", image_url:p.image_url || "",
      price:p.price ?? "", currency:p.currency || "INR", rating:p.rating ?? "",
      features:(p.features || []).join("\n"), affiliate_url:p.affiliate_url || url,
      description:"", featured:false, trending:false, asin:p.asin || ""
    });
    setStatus("Product details aa gaye. Ab Save Product dabayein.");
  }

  async function saveProduct(e) {
    e.preventDefault();
    setStatus("Saving...");
    const body = {...form, password, marketplace,
      features: form.features.split("\n").map(x=>x.trim()).filter(Boolean)
    };
    const r = await fetch("/api/products", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const d = await r.json();
    if (!r.ok) return setStatus(d.error || "Save failed");
    setStatus("Product successfully add ho gaya.");
    setForm({title:"",brand:"",image_url:"",price:"",currency:"INR",rating:"",features:"",affiliate_url:"",description:"",featured:false,trending:false,asin:""});
    setUrl("");
    loadProducts();
  }

  async function deleteProduct(id) {
    if (!confirm("Product delete karein?")) return;
    const r = await fetch("/api/products",{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,password})});
    const d = await r.json();
    setStatus(d.error || "Deleted");
    loadProducts();
  }

  async function saveSettings(e) {
    e.preventDefault();
    const r = await fetch("/api/settings",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({...settings,password})});
    const d = await r.json();
    setStatus(d.error || "Social/site settings saved.");
  }

  return (
    <main className="admin">
      <div className="container">
        <h1>Admin Panel</h1>
        <p className="small">Ye page visitors ko main navigation me nahi dikhaya gaya. Password ke bina product/API actions nahi chalenge.</p>

        <section className="panel">
          <div className="field">
            <label>Admin Password</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="ADMIN_PASSWORD" />
          </div>
        </section>

        <section className="panel">
          <h2>1. Amazon Affiliate Link → Product</h2>
          <p className="small">Amazon product URL paste karein. Creators API configured hone par title, image, price, rating/features etc. fetch honge.</p>
          <div className="row">
            <input style={{flex:1,padding:11,border:"1px solid #b8c0cc",borderRadius:6}} value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://www.amazon.in/dp/XXXXXXXXXX/?tag=yourtag-21" />
            <button className="primary" type="button" onClick={fetchAmazon}>Fetch Product</button>
          </div>
        </section>

        <section className="panel">
          <h2>2. Product Details</h2>
          <form onSubmit={saveProduct}>
            <div className="formgrid">
              <div className="field full"><label>Marketplace</label><select value={marketplace} onChange={e=>setMarketplace(e.target.value)}>{marketplaces.map(x=><option key={x}>{x}</option>)}</select></div>
              <div className="field"><label>Title</label><input value={form.title} onChange={e=>setField("title",e.target.value)} required /></div>
              <div className="field"><label>Brand</label><input value={form.brand} onChange={e=>setField("brand",e.target.value)} /></div>
              <div className="field full"><label>Image URL</label><input value={form.image_url} onChange={e=>setField("image_url",e.target.value)} required /></div>
              <div className="field"><label>Price</label><input type="number" value={form.price} onChange={e=>setField("price",e.target.value)} /></div>
              <div className="field"><label>Rating</label><input type="number" step="0.1" min="0" max="5" value={form.rating} onChange={e=>setField("rating",e.target.value)} /></div>
              <div className="field full"><label>Affiliate URL</label><input value={form.affiliate_url} onChange={e=>setField("affiliate_url",e.target.value)} required /></div>
              <div className="field full"><label>Features — one per line</label><textarea value={form.features} onChange={e=>setField("features",e.target.value)} /></div>
              <div className="field full"><label>Description</label><textarea value={form.description} onChange={e=>setField("description",e.target.value)} /></div>
              <div className="field"><label><input type="checkbox" checked={form.featured} onChange={e=>setField("featured",e.target.checked)} /> Make TOP PICK</label></div>
              <div className="field"><label><input type="checkbox" checked={form.trending} onChange={e=>setField("trending",e.target.checked)} /> Show as TRENDING</label></div>
            </div>
            <br />
            <button className="primary">Save Product</button>
          </form>
          <div className="status">{status}</div>
        </section>

        <section className="panel">
          <h2>3. Social Media — 4 Links</h2>
          <form onSubmit={saveSettings}>
            <div className="formgrid">
              <div className="field full"><label>Site Name</label><input value={settings.site_name || ""} onChange={e=>setSettings(s=>({...s,site_name:e.target.value}))} /></div>
              {settings.social_links.map((x,i)=>(
                <div className="field" key={i}>
                  <label>Social {i+1} Label</label>
                  <input value={x.label || ""} onChange={e=>setSettings(s=>({...s,social_links:s.social_links.map((a,j)=>j===i?{...a,label:e.target.value}:a)}))} placeholder="Instagram" />
                  <input value={x.url || ""} onChange={e=>setSettings(s=>({...s,social_links:s.social_links.map((a,j)=>j===i?{...a,url:e.target.value}:a)}))} placeholder="https://..." />
                </div>
              ))}
            </div>
            <br />
            <button className="primary">Save Site & Social Links</button>
          </form>
        </section>

        <section className="panel">
          <h2>Products in {marketplace}</h2>
          <div className="admin-products">
            {products.map(p=>(
              <div className="admin-item" key={p.id}>
                <div><b>{p.title}</b><div className="small">{p.featured ? "TOP PICK • " : ""}{p.trending ? "TRENDING • " : ""}{p.marketplace}</div></div>
                <button className="secondary" onClick={()=>deleteProduct(p.id)}>Delete</button>
              </div>
            ))}
            {!products.length && <div className="empty">No products yet.</div>}
          </div>
        </section>
      </div>
    </main>
  );
}
