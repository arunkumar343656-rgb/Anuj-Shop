import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HomeSections from "@/components/HomeSections";
import { supabaseAdmin } from "@/lib/supabase";

export const dynamic = "force-dynamic";

export default async function Home() {
  let products=[], settings={site_name:"DealCart India",social_links:[]};
  try {
    const db=supabaseAdmin();
    const r=await db.from("products").select("*").order("featured",{ascending:false}).order("trending",{ascending:false}).order("created_at",{ascending:false});
    products=r.data||[];
    const s=await db.from("site_settings").select("*").eq("id",1).single();
    settings=s.data||settings;
  } catch {}
  return <>
    <Header siteName={settings.site_name}/>
    <HomeSections products={products}/>
    <Footer settings={settings}/>
    <div className="bottomNav"><a href="/amazon"><b>⌂</b>Shop</a><a href="#featured"><b>♡</b>Wishlist</a><a href="/admin"><b>▤</b>Blog</a><a href="/amazon"><b>⌂</b>Home</a></div>
  </>;
}
