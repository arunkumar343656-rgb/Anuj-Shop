import "./globals.css";

export const metadata = {
  title: "DealCart India",
  description: "Affiliate shopping marketplace"
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
