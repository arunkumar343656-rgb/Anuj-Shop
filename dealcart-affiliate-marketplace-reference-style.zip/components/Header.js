import Link from "next/link";

export default function Header({siteName="DealCart India"}) {
  return <>
    <div className="ticker"><span>THIS MONTH, MANY PRODUCTS HAVE BEEN LAUNCHED — SHOP NOW AND GET UP TO 50% CASHBACK • HURRY UP • LATEST DEALS & TRENDING PRODUCTS</span></div>
    <header className="header">
      <div className="container headrow">
        <Link className="logo" href="/amazon">
          <i className="logoMark"></i>
          <div>{siteName}<small>DEALS • OFFERS • PRODUCTS</small></div>
        </Link>
        <form className="searchbar" action="/amazon">
          <input name="q" placeholder="Search for products" />
          <select name="category" defaultValue=""><option value="">SELECT CATEGORY</option><option>Electronics</option><option>Fashion</option><option>Mobile</option><option>Laptops</option></select>
          <button>⌕</button>
        </form>
        <div className="headicons"><span>♡</span><span>◌</span><span className="hideMob">◯</span></div>
      </div>
    </header>
    <nav className="nav"><div className="container navinner">
      <Link href="/amazon">HOME</Link><Link href="/about">ABOUT US</Link><Link href="/contact">CONTACT US</Link>
      <Link href="/amazon?category=electronics">ELECTRONICS</Link><Link href="/amazon?category=fashion">FASHION</Link>
      <Link href="/amazon?category=fridge">FRIDGE</Link><Link href="/amazon?category=laptops">LAPTOPS</Link>
      <Link href="/amazon?category=mobile">MOBILE</Link><Link href="/amazon?category=washing-machines">WASHING MACHINES</Link>
      <Link href="/marketplace">MARKETPLACE</Link><Link href="/refund-policy">REFUND POLICY</Link><Link href="/disclaimer">DISCLAIMER</Link>
    </div></nav>
  </>;
}
