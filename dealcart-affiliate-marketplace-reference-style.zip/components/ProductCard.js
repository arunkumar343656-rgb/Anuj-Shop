export default function ProductCard({ product }) {
  const price = product.price != null
    ? new Intl.NumberFormat("en-IN", { style: "currency", currency: product.currency || "INR", maximumFractionDigits: 0 }).format(product.price)
    : "Check price";

  return (
    <article className={`card ${product.featured ? "featured" : ""}`}>
      {product.featured && <div className="featured-label">TOP PICK</div>}
      <img src={product.image_url} alt={product.title} loading="lazy" />
      <div className="cardbody">
        <div className="badges">
          {product.trending && <span className="badge">🔥 Trending</span>}
          <span className="badge">{product.marketplace}</span>
        </div>
        <div className="brand">{product.brand || "Featured product"}</div>
        <h3>{product.title}</h3>
        {product.rating ? <div className="rating">★ {product.rating}/5</div> : null}
        <div className="price">{price}</div>
        {Array.isArray(product.features) && product.features.length > 0 ? (
          <ul className="features">
            {product.features.slice(0, 4).map((f, i) => <li key={i}>{f}</li>)}
          </ul>
        ) : null}
        <a className="buy" href={product.affiliate_url} target="_blank" rel="nofollow sponsored noopener">
          View on {product.marketplace === "amazon" ? "Amazon" : product.marketplace}
        </a>
      </div>
    </article>
  );
}
