import ProductCard from "./ProductCard";

export default function HomeSections({products=[]}) {
  const featured = products.filter(p=>p.featured);
  const trending = products.filter(p=>p.trending && !p.featured);
  const regular = products.filter(p=>!p.featured && !p.trending);
  const hot = products.slice(0,3);
  const hero = products.find(p=>p.image_url)?.image_url || "/hero-placeholder.svg";

  return <>
    <section className="heroArea">
      <div className="container heroFrame">
        <div className="hotBox">
          <div className="boxTitle">HOT SELLING PRODUCT</div>
          {hot.map(p=><div className="hotItem" key={p.id}>
            <img src={p.image_url} alt="" />
            <div><b>{p.title}</b><div className="p">{p.price ? `Price: ₹${Number(p.price).toLocaleString("en-IN")}` : "Latest price"}</div><small>Details ↗</small></div>
          </div>)}
          {!hot.length && <div className="hotItem"><div></div><div><b>Top products will appear here</b></div></div>}
        </div>
        <div className="sliderBox">
          <div className="heroSlide"><img className="heroArt" src={hero} alt="Featured products" /></div>
          <div className="slideDots">● • • • • •</div>
        </div>
        <div className="platformBox">
          <div className="boxTitle">POPULAR PLATFORM</div>
          <div className="platformItem">Ⓜ <span>Myntra</span></div>
          <div className="platformItem">m <span>meesho</span></div>
          <div className="platformItem">Flipkart <span>▣</span></div>
          <div className="platformItem">amazon</div>
        </div>
      </div>
    </section>

    <section className="categories">
      <div className="container catGrid">
        {[
          ["❄️","AC","15 products"],["👗","FASHION","14 products"],["🧊","FRIDGE","13 products"],
          ["💻","LAPTOPS","13 products"],["📱","MOBILE","14 products"],["🧺","WASHING MACHINES","14 products"]
        ].map(([icon,name,count])=><Link className="cat" key={name} href={`/amazon?category=${name.toLowerCase()}`}><div className="catIcon">{icon}</div><b>{name}</b><small>{count}</small></Link>)}
      </div>
    </section>

    <section className="intro"><div className="container">
      <h1>🔥 Discover the Best & Top-Selling Products – All in One Place!</h1>
      <p>Find trusted, trending and top-selling products in one place. We bring useful deals, customer favourites and highly-rated items together so you can shop smart and save time.</p>
    </div></section>

    {featured.length>0 && <section className="section" id="featured"><div className="container"><h2>⭐ Top Picks For You</h2><div className="grid">{featured.map(p=><ProductCard key={p.id} product={p}/>)}</div></div></section>}
    {trending.length>0 && <section className="section" id="trending"><div className="container"><h2>🔥 Trending Products</h2><div className="grid">{trending.map(p=><ProductCard key={p.id} product={p}/>)}</div></div></section>}
    <section className="section"><div className="container"><h2>🛍️ Latest Products</h2>{regular.length ? <div className="grid">{regular.map(p=><ProductCard key={p.id} product={p}/>)}</div> : <div className="empty">Admin panel se products add karne ke baad yahan automatically dikhेंगे.</div>}</div></section>
  </>;
}
