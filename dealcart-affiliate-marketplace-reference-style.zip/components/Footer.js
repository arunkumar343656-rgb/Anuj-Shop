export default function Footer({ settings }) {
  const links = settings?.social_links || [];
  return (
    <footer className="footer">
      <div className="container footergrid">
        <div>
          <h3>{settings?.site_name || "DealCart India"}</h3>
          <p className="small" style={{color:"#cbd5e1"}}>
            We may earn a commission when you buy through qualifying affiliate links.
            Prices and availability can change on the merchant website.
          </p>
        </div>
        <div>
          <h4>Marketplaces</h4>
          <p className="small"><a href="/amazon">Amazon</a></p>
          <p className="small"><a href="/flipkart">Flipkart</a></p>
          <p className="small"><a href="/meesho">Meesho</a></p>
          <p className="small"><a href="/myntra">Myntra</a></p>
        </div>
        <div>
          <h4>Social</h4>
          <div className="social">
            {links.map((x, i) => x.url ? <a key={i} href={x.url} target="_blank" rel="noopener">{x.label || `Social ${i+1}`}</a> : null)}
          </div>
        </div>
      </div>
    </footer>
  );
}
