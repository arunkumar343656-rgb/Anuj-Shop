import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import * as cheerio from "cheerio";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  app.use(express.json());

  app.post("/api/fetch-product", async (req, res) => {
    try {
      const { url } = req.body;
      if (!url) return res.status(400).json({ error: "URL is required" });

      let parsedUrl = url;
      if (!parsedUrl.startsWith('http://') && !parsedUrl.startsWith('https://')) {
        parsedUrl = 'https://' + parsedUrl;
      }
      
      console.log(`Fetching URL: ${parsedUrl}`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 seconds timeout
      
      let html = "";
      try {
        const response = await fetch(parsedUrl, {
          signal: controller.signal,
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
        });
        clearTimeout(timeoutId);
        html = await response.text();
      } catch (fetchErr) {
        clearTimeout(timeoutId);
        console.error("Fetch failed or timed out:", fetchErr);
        // Fallback to empty HTML to let Gemini try or just return default
      }
      
      const $ = cheerio.load(html || "<html><body></body></html>");

      // Extract basic info from OpenGraph tags
      let title = $('meta[property="og:title"]').attr('content') || $('title').text() || '';
      let image = $('meta[property="og:image"]').attr('content') || $('#landingImage').attr('src') || '';
      let description = $('meta[property="og:description"]').attr('content') || $('meta[name="description"]').attr('content') || '';
      let price = '';
      
      // Try extracting price using common selectors
      const amzPrice = $('.a-price-whole').first().text().trim();
      if (amzPrice) price = '₹' + amzPrice.replace(/[^0-9,]/g, '');
      
      const fkPrice = $('div[class*="Nx9bqj"]').first().text().trim() || $('div._30jeq3').first().text().trim();
      if (fkPrice && fkPrice.includes('₹')) price = fkPrice;

      // Detect out of stock
      let inStock = true;
      const bodyText = $('body').text().toLowerCase();
      if (bodyText.includes('currently unavailable') || bodyText.includes('out of stock') || bodyText.includes('sold out')) {
        inStock = false;
      }

      // If price is missing or title seems like a bot-check (common with Amazon), use Gemini fallback
      if (!price || title.toLowerCase().includes("amazon.in") || title.toLowerCase().includes("bot check")) {
         try {
             const apiKey = process.env.GEMINI_API_KEY;
             if (apiKey) {
               const ai = new GoogleGenAI({ apiKey });
               
               // Extract a reasonable chunk of text to avoid massive context but capture enough data
               const textSnippet = $('body').text().replace(/\s+/g, ' ').substring(0, 15000); 
               
               const prompt = `
                 Extract product information from this webpage text.
                 URL: ${url}
                 
                 Return ONLY a valid JSON object with these exact keys:
                 - title: The actual product name (string)
                 - price: The current price including currency symbol, e.g., '₹1,499' (string). Look closely for '₹' or 'Rs.'.
                 - description: A short 1-2 sentence description (string)
                 - inStock: true if available, false if out of stock (boolean)
                 
                 If you cannot find a value, use an empty string. If you cannot determine stock, default to true. Do not include markdown formatting, just the raw JSON.
                 
                 Text snippet:
                 ${textSnippet}
               `;
               
               const aiResponse = await ai.models.generateContent({
                 model: "gemini-2.5-flash",
                 contents: prompt,
               });
               
               const aiText = aiResponse.text;
               const jsonMatch = aiText.match(/\{[\s\S]*\}/);
               
               if (jsonMatch) {
                  const parsed = JSON.parse(jsonMatch[0]);
                  if (parsed.title && parsed.title.length > 5) title = parsed.title;
                  if (parsed.price) price = parsed.price;
                  if (parsed.description) description = parsed.description;
                  if (parsed.inStock !== undefined) inStock = parsed.inStock;
               }
             }
         } catch(e) {
             console.error("Gemini AI parsing failed", e);
         }
      }

      // Final cleanup
      title = title.replace(/Buy /i, '').split('|')[0].trim();
      if (title.length > 80) title = title.substring(0, 80) + '...';

      // Ensure we have some default image if all scraping fails
      if (!image) image = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400';

      res.json({ title, image, description, price, inStock });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
