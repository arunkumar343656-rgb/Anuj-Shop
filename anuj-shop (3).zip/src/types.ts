export interface Product {
  id: number;
  platform: string;
  category: string;
  title: string;
  image: string;
  price: string;
  rating: string;
  reviews: string;
  link: string;
  isTop: boolean;
  description?: string;
  inStock?: boolean;
}
