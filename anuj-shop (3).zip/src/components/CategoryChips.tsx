import React from 'react';

interface Category {
  id: string;
  label: string;
}

interface CategoryChipsProps {
  categories: Category[];
  currentCategory: string;
  setCurrentCategory: (c: string) => void;
}

export function CategoryChips({ categories, currentCategory, setCurrentCategory }: CategoryChipsProps) {
  return (
    <div className="flex gap-2.5 overflow-x-auto pb-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
      {categories.map(cat => (
        <button
          key={cat.id}
          onClick={() => setCurrentCategory(cat.id)}
          className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-colors border ${
            currentCategory === cat.id
              ? 'bg-[#131921] text-white border-[#131921]'
              : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
          }`}
        >
          {cat.label}
        </button>
      ))}
    </div>
  );
}
