import React from 'react';

interface HeaderProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  toggleAdmin: () => void;
}

export function Header({ searchQuery, setSearchQuery, toggleAdmin }: HeaderProps) {
  return (
    <header className="bg-[#131921] text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap gap-4 items-center justify-between">
        <a href="#" className="text-[#ff9900] text-2xl font-bold no-underline whitespace-nowrap">
          Anuj Shop
        </a>
        
        <div className="flex-1 w-full max-w-xl flex items-center">
          <input 
            type="text" 
            placeholder="Search products across all categories..." 
            className="w-full px-4 py-2.5 rounded-l-md text-black outline-none text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button className="bg-[#ff9900] hover:bg-[#e48a00] text-[#131921] px-5 py-2.5 rounded-r-md font-bold transition-colors">
            Search
          </button>
        </div>
        
        <button 
          onClick={toggleAdmin}
          className="border border-[#ff9900] text-[#ff9900] px-4 py-1.5 rounded-md font-bold hover:bg-[#ff9900] hover:text-[#131921] transition-colors whitespace-nowrap"
        >
          Malik Panel
        </button>
      </div>
    </header>
  );
}
