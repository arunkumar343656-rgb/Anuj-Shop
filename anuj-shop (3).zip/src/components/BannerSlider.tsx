import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface Slide {
  id: number;
  image: string;
  title: string;
  description: string;
}

interface BannerSliderProps {
  slides: Slide[];
}

export function BannerSlider({ slides }: BannerSliderProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="relative w-full h-[280px] rounded-xl overflow-hidden shadow-lg bg-gray-900">
      <AnimatePresence mode="popLayout">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <img 
            src={slides[currentSlide].image} 
            alt={slides[currentSlide].title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-5 left-5 bg-black/65 text-white px-5 py-3 rounded-lg backdrop-blur-sm">
            <h2 className="text-xl font-bold m-0 mb-1">{slides[currentSlide].title}</h2>
            <p className="m-0 text-sm opacity-90">{slides[currentSlide].description}</p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
