import React, { useState } from 'react';

interface AdminPanelProps {
  onAddProduct: (link: string, platform: string, category: string, fetchedData: any) => void;
  platforms: string[];
}

export function AdminPanel({ onAddProduct, platforms }: AdminPanelProps) {
  const [link, setLink] = useState('');
  const [platform, setPlatform] = useState(platforms[0]);
  const [category, setCategory] = useState('Electronics');
  const [isFetching, setIsFetching] = useState(false);

  const categoriesList = ['Electronics', 'Fashion', 'Home', 'Beauty', 'Offers'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!link) return;
    
    setIsFetching(true);
    try {
      const response = await fetch('/api/fetch-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: link })
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch from server');
      }
      
      const data = await response.json();
      onAddProduct(link, platform, category, data);
    } catch (error) {
      console.error('Failed to fetch product data:', error);
      alert('Failed to automatically fetch product data. It will be added manually.');
      onAddProduct(link, platform, category, null);
    } finally {
      setIsFetching(false);
      setLink('');
    }
  };

  return (
    <div className="bg-white p-5 rounded-lg shadow-md border-l-4 border-[#ff9900]">
      <h3 className="text-xl font-bold text-[#131921] mb-4">👑 Admin / Malik Control Panel</h3>
      <form onSubmit={handleSubmit} className="flex flex-wrap gap-3">
        <select 
          value={platform} 
          onChange={(e) => setPlatform(e.target.value)}
          className="flex-1 min-w-[150px] p-2.5 border border-gray-300 rounded-md outline-none focus:border-[#ff9900]"
        >
          {platforms.map(p => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
        
        <select 
          value={category} 
          onChange={(e) => setCategory(e.target.value)}
          className="flex-1 min-w-[150px] p-2.5 border border-gray-300 rounded-md outline-none focus:border-[#ff9900]"
        >
          {categoriesList.map(c => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        
        <input 
          type="text" 
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="Paste Affiliate Product Link Here..." 
          className="flex-[2] min-w-[200px] p-2.5 border border-gray-300 rounded-md outline-none focus:border-[#ff9900]"
        />
        
        <button 
          type="submit"
          disabled={isFetching}
          className="bg-[#131921] text-[#ff9900] px-6 py-2.5 rounded-md font-bold hover:bg-gray-800 transition-colors whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isFetching ? 'Fetching...' : 'Auto Add & Pin to Top'}
        </button>
      </form>
    </div>
  );
}
