import React from 'react';

interface NavigationProps {
  platforms: string[];
  currentPlatform: string;
  setCurrentPlatform: (p: string) => void;
}

export function Navigation({ platforms, currentPlatform, setCurrentPlatform }: NavigationProps) {
  return (
    <nav className="bg-[#232f3e] py-2 overflow-x-auto whitespace-nowrap [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
      <div className="max-w-7xl mx-auto px-4 flex gap-2">
        {platforms.map(platform => (
          <button
            key={platform}
            onClick={() => setCurrentPlatform(platform)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              currentPlatform === platform
                ? 'bg-[#ff9900] text-[#131921] font-bold'
                : 'text-white hover:bg-[#ff9900] hover:text-[#131921]'
            }`}
          >
            {platform} Store
          </button>
        ))}
      </div>
    </nav>
  );
}
