import React from 'react';

export function Footer() {
  return (
    <footer className="bg-[#131921] text-white py-8 mt-auto text-center">
      <div className="max-w-7xl mx-auto px-4">
        <p className="mb-4">Follow Us & Get Daily Best Offer Updates:</p>
        <div className="flex justify-center flex-wrap gap-4 mb-6">
          {['YouTube', 'Instagram', 'WhatsApp', 'Facebook'].map(social => (
            <a 
              key={social}
              href="#" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-[#ff9900] border border-[#ff9900] px-4 py-1.5 rounded-full text-sm hover:bg-[#ff9900] hover:text-[#131921] transition-colors"
            >
              {social}
            </a>
          ))}
        </div>
        <p className="text-xs text-gray-400">
          © 2026 Anuj Shop. Affiliate Tag: ArunZiQ
        </p>
      </div>
    </footer>
  );
}
