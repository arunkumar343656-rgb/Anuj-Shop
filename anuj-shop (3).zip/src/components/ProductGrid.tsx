import React from 'react';
import { Product } from '../types';
import { Share2, Star } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
}

export function ProductGrid({ products }: ProductGridProps) {
  const shareProduct = async (title: string, link: string) => {
    if (navigator.share) {
      try {
        await navigator.share({ title, url: link });
      } catch (err) {
        console.error("Error sharing:", err);
      }
    } else {
      navigator.clipboard.writeText(link);
      alert('Link Copied to Clipboard!');
    }
  };

  if (products.length === 0) {
    return (
      <div className="w-full text-center p-10 text-gray-500">
        No products found in this category.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
      {products.map(product => (
        <div 
          key={product.id} 
          className="bg-white rounded-lg p-4 flex flex-col justify-between shadow-sm hover:shadow-md hover:-translate-y-1 transition-all relative border border-gray-100"
        >
          {product.isTop && (
            <span className="absolute top-2 left-2 bg-[#e47911] text-white px-2 py-1 text-[10px] font-bold rounded z-10">
              TOP FEATURED
            </span>
          )}
          
          <div className="w-full h-[180px] mb-3 relative rounded overflow-hidden">
            <img 
              src={product.image} 
              alt={product.title} 
              className="w-full h-full object-contain"
            />
          </div>
          
          <div className="flex-1 flex flex-col">
            <h4 className="text-sm font-semibold text-[#0f1111] leading-snug line-clamp-2 h-[40px] mb-2" title={product.title}>
              {product.title}
            </h4>
            
            {product.description && (
              <p className="text-xs text-gray-600 line-clamp-2 mb-2 leading-relaxed" title={product.description}>
                {product.description}
              </p>
            )}
            
            <div className="flex items-center text-[#ffa41c] text-sm mb-1.5">
              <Star className="w-4 h-4 fill-current mr-1" />
              <span>{product.rating}</span>
              <span className="text-[#565959] text-xs ml-1">({product.reviews} reviews)</span>
            </div>
            
            <div className="mb-3 flex items-center justify-between">
              {product.price ? (
                <span className="text-lg font-bold text-[#b12704]">{product.price}</span>
              ) : (
                <span className="text-xs text-[#767676] italic">Check Price on Site</span>
              )}
              {product.inStock === false && (
                <span className="text-[10px] font-bold text-red-600 bg-red-100 px-2 py-0.5 rounded">OUT OF STOCK</span>
              )}
            </div>
          </div>
          
          <div className="mt-auto flex flex-col gap-2">
            <a 
              href={product.link} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full block text-center bg-[#ffd814] hover:bg-[#f7ca00] text-[#0f1111] border border-[#fcd200] py-2.5 rounded-full font-bold text-sm transition-colors"
            >
              Buy Now
            </a>
            
            <button 
              onClick={() => shareProduct(product.title, product.link)}
              className="w-full flex items-center justify-center gap-1.5 bg-[#e7e9ec] hover:bg-[#d5d9d9] border border-[#adb1b8] text-[#0f1111] py-1.5 rounded-md text-xs transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              Share Product
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
