/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { initialProducts, platforms, categories, bannerSlides, AFFILIATE_TAG } from './data';
import { Product } from './types';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { BannerSlider } from './components/BannerSlider';
import { AdminPanel } from './components/AdminPanel';
import { CategoryChips } from './components/CategoryChips';
import { ProductGrid } from './components/ProductGrid';
import { Footer } from './components/Footer';

export default function App() {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [currentPlatform, setCurrentPlatform] = useState('Amazon');
  const [currentCategory, setCurrentCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);

  const handleAddProduct = (linkInput: string, platform: string, category: string, fetchedData: any = null) => {
    if (!linkInput) {
      alert('Please paste a product link!');
      return;
    }

    let finalLink = linkInput.includes('?') ? `${linkInput}&tag=${AFFILIATE_TAG}` : `${linkInput}?tag=${AFFILIATE_TAG}`;

    const newProduct: Product = {
      id: Date.now(),
      platform: platform,
      category: category,
      title: fetchedData?.title || `Auto Added ${category} Item (${platform})`,
      image: fetchedData?.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
      price: fetchedData?.price || '',
      rating: '4.8',
      reviews: Math.floor(Math.random() * 1000 + 50).toString(),
      link: finalLink,
      isTop: true,
      description: fetchedData?.description || '',
      inStock: fetchedData?.inStock !== false
    };

    setProducts([newProduct, ...products]);
    setCurrentPlatform(platform);
    setCurrentCategory(category);
    alert('Product Successfully Added and Pinned to Top!');
  };

  const filteredProducts = products
    .filter(p => p.platform === currentPlatform)
    .filter(p => currentCategory === 'All' || p.category === currentCategory)
    .filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => Number(b.isTop) - Number(a.isTop));

  return (
    <div className="min-h-screen bg-[#f4f7f9] text-[#111] font-sans flex flex-col">
      <Header 
        searchQuery={searchQuery} 
        setSearchQuery={setSearchQuery} 
        toggleAdmin={() => setIsAdminPanelOpen(!isAdminPanelOpen)} 
      />
      <Navigation 
        platforms={platforms} 
        currentPlatform={currentPlatform} 
        setCurrentPlatform={setCurrentPlatform} 
      />
      
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 flex flex-col gap-6">
        <BannerSlider slides={bannerSlides} />
        
        {isAdminPanelOpen && (
          <AdminPanel onAddProduct={handleAddProduct} platforms={platforms} />
        )}
        
        <div>
          <h3 className="font-semibold text-lg mb-3">Categories</h3>
          <CategoryChips 
            categories={categories} 
            currentCategory={currentCategory} 
            setCurrentCategory={setCurrentCategory} 
          />
        </div>
        
        <div>
          <h2 className="text-xl font-bold mb-4">{currentPlatform} Trending Products</h2>
          <ProductGrid products={filteredProducts} />
        </div>
      </main>

      <Footer />
    </div>
  );
}
