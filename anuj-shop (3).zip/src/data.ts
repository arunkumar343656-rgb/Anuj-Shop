import { Product } from './types';

export const AFFILIATE_TAG = "ArunZiQ";

export const initialProducts: Product[] = [
  {
    id: 1,
    platform: 'Amazon',
    category: 'Electronics',
    title: 'Wireless Bluetooth Headphone with Deep Bass',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400',
    price: '₹1,499',
    rating: '4.5',
    reviews: '1,240',
    link: 'https://www.amazon.in/dp/sample?tag=' + AFFILIATE_TAG,
    isTop: true
  },
  {
    id: 2,
    platform: 'Amazon',
    category: 'Electronics',
    title: 'Smart Watch with Heart Rate & SpO2 Monitor',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
    price: '₹2,199',
    rating: '4.2',
    reviews: '850',
    link: 'https://www.amazon.in/dp/sample2?tag=' + AFFILIATE_TAG,
    isTop: false
  },
  {
    id: 3,
    platform: 'Myntra',
    category: 'Fashion',
    title: 'Casual Stylish Denim Jacket for Men',
    image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=400',
    price: '₹999',
    rating: '4.7',
    reviews: '530',
    link: 'https://www.myntra.com/sample?tag=' + AFFILIATE_TAG,
    isTop: true
  }
];

// Banner slides
export const bannerSlides = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80',
    title: 'Mega Trending Deals',
    description: 'Up to 70% off on top branded products'
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=1200&q=80',
    title: 'Latest Smart Gadgets',
    description: 'Best Headphones, Smartwatches & Accessories'
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1200&q=80',
    title: 'Exclusive Fashion Collection',
    description: 'Top Fashion trends from Myntra & Flipkart'
  }
];

export const platforms = ['Amazon', 'Flipkart', 'Meesho', 'Myntra'];

export const categories = [
  { id: 'All', label: 'All Categories' },
  { id: 'Electronics', label: 'Electronics' },
  { id: 'Fashion', label: 'Fashion' },
  { id: 'Home', label: 'Home & Kitchen' },
  { id: 'Beauty', label: 'Beauty & Personal Care' },
  { id: 'Offers', label: "Today's Deals" }
];
